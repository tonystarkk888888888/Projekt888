# SCM Digital Twin AI (Pro)

## Features
- Simulation
- Forecasting (ML)
- PostgreSQL persistence
- KPI tracking

## Deployment
Backend → Render
Frontend → Streamlit Cloud

Set environment variable:
DATABASE_URL=your_postgres_url
